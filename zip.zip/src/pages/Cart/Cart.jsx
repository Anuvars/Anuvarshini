import React from 'react';
import CartPayment from './components/CartPayment/CartPayment';

const Cart = () => {
    return (
        <div className="cart page-container ">
            <CartPayment />
        </div>
    )
}

export default Cart