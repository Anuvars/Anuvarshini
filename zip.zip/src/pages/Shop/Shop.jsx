import React from 'react';
import ShopProducts from './components/ShopProducts/ShopProducts';


const Shop = () => {
    return (
        <div className="shop page-container">
            <ShopProducts />
        </div>
    )
}

export default Shop;