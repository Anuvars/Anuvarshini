let testimonials = [
    {
        id: 1,
        user: "Charu",
        comment: "Good taste maintained in hygenic manner with affordable prices",
        image: "https://i.pinimg.com/originals/40/41/af/4041af716c819acd30a29f5441b05e1c.png",
    }, {
        id: 2,
        user: "Anu",
        comment: "Good products always keep customer happy and healthy",
        image: "http://img.picturequotes.com/2/601/600831/happiness-is-a-by-product-of-service-quote-1.jpg",
    }, {
        id: 3,
        user: "Paul",
        comment: "Hygenic and fastest delivery",
        image: "https://i.pinimg.com/736x/fb/7e/36/fb7e3652e26d805267fddbb742e0f397--quality-of-work-photography-portraits.jpg",
    }
]

export default testimonials;